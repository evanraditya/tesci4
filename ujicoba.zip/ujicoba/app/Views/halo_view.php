<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $title;?></title>
    </head>
    <body>
    <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Employee_ID</th>
                            <th>Nama</th>
                            <th>Tempat Lahir</th>
                        </tr> 
                    </thead>
                    <tbody>
                        <?php $no=1; foreach($data as $isi){?>
                            <tr>
                                <td><?= $no;?></td>
                                <td><?= $isi['NAMA'];?></td>
                                <td><?= $isi['tL'];?></td>
                            </tr>
                        <?php $no++;}?>
                    </tbody>   

                </table>
    </body>
</html>