<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Tes extends Migration
{
    public function up()
    {
        $this->forge->addField([
			'EMP_ID'          => [
				'type'           => 'VARCHAR',
				'constraint'     => 20,
			],
			'NAMA'       => [
				'type'           => 'VARCHAR',
				'constraint'     => 100,
			],
			'TL'      => [
				'type'           => 'VARCHAR',
				'constraint'     => 20,
			],
		]);

		$this->forge->createTable('tabel_tes', TRUE);
    }

    public function down()
    {
        //
    }
}
