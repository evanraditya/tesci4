<?php

namespace App\Controllers;

use App\Models\tesmodel;

class Home extends BaseController

{
    public function index()
    {
        $model = new tesmodel;
        $data['tesmodels'] = $model->getEmploy();
        echo view('halo_view',$data);
    }

    // {
    //     $data['title']  = 'Hallo Dunia !';
    //     $data['msg']    = 'Selamat datang di CodeIgniter 4';
	// 	echo view('halo_view',$data);
	// }

    // public function view()
    // {
    //     $tesmod = new tesmodel();
    //     $data = array(
    //         'EMP_ID' => $this->request->getPost('EMP_ID'),
    //         'NAMA' => $this->request->getPost('NAMA'),
    //         'TL' => $this->request->getPost('TL'),
    //     );
	// 	echo view('news_detail', $data);
    // }

    // public function procces()
    // {
    //     $this->tesmodel->insert([
    //         'EMP_ID' => $this->request->getPost('EMP_ID'),
    //         'NAMA' => $this->request->getPost('NAMA'),
    //         'TL' => $this->request->getPost('TL'),
    //     ]);
    //     return redirect('tesmodel')->with('success', 'Data Added Successfully');	
    // }


}
