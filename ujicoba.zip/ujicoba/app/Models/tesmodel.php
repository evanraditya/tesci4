<?php

namespace App\Models;

use CodeIgniter\Model;

class tesmodel extends Model
{
    protected $table      = 'tabel_tes';

    public function getEmploy($id = false)
    {
        if($id === false){
            return $this->findAll();
        }else{
            return $this->getWhere(['EMP_ID' => $id]);
        }   
    }

}