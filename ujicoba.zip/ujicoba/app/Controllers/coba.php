<?php

namespace App\Controllers;

use App\Models\tesmodel;

class Home extends BaseController{
    public function procces()
    {
        $tes = new tesmodel();
        $this->$tes->insert([
            'EMP_ID' => $this->request->getPost('EMP_ID'),
            'NAMA' => $this->request->getPost('NAMA'),
            'TL' => $this->request->getPost('TL'),
        ]);

		return redirect('welocome_message')->with('success', 'Data Added Successfully');	

    }
}
